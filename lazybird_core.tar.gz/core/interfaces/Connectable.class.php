<?php
interface Connectable
{
    function setConnection($name, $path);
} 

?>