<?php
interface Relatable
{
    public function loadExpression();
}
?>