<?php
Interface Observable
{
    public static function getValues($method,$class=null);
}
?>