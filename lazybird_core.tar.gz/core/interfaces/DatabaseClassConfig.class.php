<?php
interface DatabaseClassConfig
{
    public function getDatabaseParans();
}
?>