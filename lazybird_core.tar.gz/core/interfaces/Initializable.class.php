<?php
interface Initializable
{
    public function initialize();
}
?>
