<?php
Interface HttpReturnable
{
    public function get();
}
?>