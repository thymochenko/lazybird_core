<?php
abstract class GlobalConfig
{
    abstract static function _setConfig(array $paran);
	abstract static function _getConfig();
}
?>
