<?php
abstract class ModelComponent
{
    abstract static function initialize();
}
?>