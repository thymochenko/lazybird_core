<?php

require('C:\www\Smarty\libs\Smarty.class.php');

$smarty = new smarty;

$smarty->assign('name','tolo');

$smarty->display('C:\www\Smarty\index.tpl');
?>

