<?php
// $Id: pager_include.php,v 1.1 2003/11/30 17:30:01 quipo Exp $
require_once 'Pager/Pager.php';
?>